package gui.colors;
import java.awt.Color;

public class SecondaryColor extends Color {
    private static final long serialVersionUID = 1L;

    public  SecondaryColor() {
        super(101, 147, 74);
        // super(0xffd20a);
    }
}
