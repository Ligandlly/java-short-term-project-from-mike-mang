package gui.colors;
import java.awt.Color;

public class PrimaryColor extends Color {
    private static final long serialVersionUID = 1L;

    public PrimaryColor() {
        // super(81, 119, 36);
        super(64, 116, 52);
        // super(0x1d99bb);
    }
}
