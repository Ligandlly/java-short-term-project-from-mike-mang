package gui.colors;
import java.awt.Color;

public class HighlightColor extends Color{
    private static final long serialVersionUID = 1L;

    public HighlightColor() {
        super(253, 203, 0);
        // super(0x000f30);
    }
}
